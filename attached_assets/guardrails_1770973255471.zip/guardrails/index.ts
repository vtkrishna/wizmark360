/**
 * AI Agentic Platform Guardrails
 * 
 * This package provides guardrails and standards for building AI agentic
 * orchestration platforms with TypeScript/Node.js.
 * 
 * @module ai-platform-guardrails
 */

// Guardrails
export { 
  FileCreationGuardrail, 
  createFileGuarded,
  VerificationResult as FileVerificationResult 
} from './guardrails/file-creation';

export { 
  FunctionalitySearchGuardrail, 
  createFunctionGuarded,
  FunctionalitySearchResult,
  FunctionalityVerificationResult 
} from './guardrails/functionality-search';

// Security
export { 
  DataIsolationGuardrail, 
  userScoped, 
  UserScopedModel,
  IsolationWarning 
} from './security/data-isolation';

// Storage
export { 
  StoragePlanner, 
  PersistenceLevel, 
  StorageType,
  StorageRequirement,
  StorageValidationWarning,
  STORAGE_REQUIREMENTS_TEMPLATE 
} from './storage/planning';

// Database
export { 
  SchemaValidator, 
  ColumnNamingStandards,
  SchemaValidationError,
  ColumnValidationResult 
} from './database/schema-validation';

// Session
export { 
  SessionAuditor, 
  CrossPlatformSession,
  SESSION_SCHEMA,
  SessionRequirement,
  SessionValidationError,
  SessionSecurityIssue 
} from './session/audit';

// Standards
export { 
  NamingStandards,
  NamingConventionLinter,
  NamingViolation,
  LintResults,
  NamingValidationResult,
  NameType 
} from './standards/naming';

export { 
  NamingConventionLinter as NamingLinter,
  NamingViolation as LinterNamingViolation,
  LintResults as LinterResults 
} from './standards/naming-linter';

// Config
export { 
  getConfig, 
  validateConfig, 
  validateConfigOrExit,
  resetConfig,
  AppConfig,
  DatabaseConfig,
  CacheConfig 
} from './config/settings';

export { 
  FILE_REGISTRY,
  getFileInfo,
  registerFile,
  listFilesByOwner,
  isFileRegistered,
  getAllRegisteredFiles,
  FileRegistryEntry 
} from './config/file-registry';

export { 
  TERMINOLOGY_GLOSSARY,
  getPreferredTerm,
  validateTermUsage,
  printGlossary,
  getDeprecatedTerms,
  TermDefinition,
  TermViolation,
  Domain 
} from './config/terminology-glossary';

// Scripts
export { 
  HardcodedValueDetector, 
  printResults as printHardcodedResults,
  HardcodedFinding,
  ScanResults 
} from './scripts/detect-hardcoded';

export { 
  ConfigAuditor, 
  printResults as printAuditResults,
  ConfigViolation,
  AuditResults 
} from './scripts/audit-config';

export { 
  findDuplicateFiles, 
  printResults as printDuplicateResults,
  DuplicateResults 
} from './scripts/detect-duplicates';

// Re-exports for convenience
export { default } from './guardrails/file-creation';
