/**
 * MANDATORY: Hardcoded Value Detection Script
 * Run in CI/CD to detect hardcoded values in the codebase.
 * 
 * Usage:
 *   npm run detect-hardcoded
 *   or
 *   npx ts-node src/scripts/detect-hardcoded.ts
 */

import * as fs from 'fs';
import * as path from 'path';
import { glob } from 'glob';

export interface HardcodedFinding {
  file: string;
  line: number;
  column: number;
  match: string;
  category: 'secrets' | 'urls' | 'magic_numbers' | 'file_paths';
  severity: 'CRITICAL' | 'WARNING' | 'INFO';
  message: string;
}

export interface ScanResults {
  filesScanned: number;
  findings: HardcodedFinding[];
  criticalCount: number;
  warningCount: number;
  infoCount: number;
}

export class HardcodedValueDetector {
  private readonly DANGEROUS_PATTERNS: Record<string, {
    patterns: RegExp[];
    severity: 'CRITICAL' | 'WARNING' | 'INFO';
    message: string;
    exceptions?: string[];
  }> = {
    secrets: {
      patterns: [
        /password\s*=\s*["'][^"']+["']/i,
        /secret\s*=\s*["'][^"']+["']/i,
        /token\s*=\s*["'][^"']+["']/i,
        /api_key\s*=\s*["'][^"']+["']/i,
        /key\s*=\s*["'][^"']{16,}["']/i,
      ],
      severity: 'CRITICAL',
      message: 'Hardcoded secret detected',
    },
    urls: {
      patterns: [
        /https?:\/\/[^\s\)"']+/i,
      ],
      severity: 'WARNING',
      message: 'Hardcoded URL detected',
      exceptions: ['localhost', '127.0.0.1', 'example.com', '0.0.0.0'],
    },
    magic_numbers: {
      patterns: [
        /\b\d{4,}\b/,
        /\b(3306|5432|6379|8080|3000|8000|5000)\b/,
      ],
      severity: 'INFO',
      message: 'Potential magic number',
    },
    file_paths: {
      patterns: [
        /["']\/[a-zA-Z_]+\/[a-zA-Z_/]+["']/,
        /["']C:\\\\[^"']+["']/,
      ],
      severity: 'WARNING',
      message: 'Hardcoded file path detected',
    },
  };

  private readonly ALLOWED_VALUES: RegExp[] = [
    /["']true["']/,
    /["']false["']/,
    /["']null["']/,
    /["']undefined["']/,
    /["']["']/,
    /\b0\b/,
    /\b1\b/,
  ];

  private rootDir: string;
  public findings: HardcodedFinding[] = [];

  constructor(rootDir: string = '.') {
    this.rootDir = rootDir;
  }

  /**
   * Scan a single file for hardcoded values
   */
  public scanFile(filePath: string): HardcodedFinding[] {
    const findings: HardcodedFinding[] = [];

    try {
      const content = fs.readFileSync(filePath, 'utf-8');
      const lines = content.split('\n');

      for (let lineNum = 0; lineNum < lines.length; lineNum++) {
        const line = lines[lineNum];

        // Skip comments
        if (line.trim().startsWith('//') || line.trim().startsWith('*') || line.trim().startsWith('/*')) {
          continue;
        }

        for (const [category, config] of Object.entries(this.DANGEROUS_PATTERNS)) {
          for (const pattern of config.patterns) {
            const matches = line.matchAll(pattern);
            for (const match of matches) {
              if (!match) continue;

              const matchedValue = match[0];

              // Check if value is allowed
              if (this.ALLOWED_VALUES.some(allowed => allowed.test(matchedValue))) {
                continue;
              }

              // Check exceptions
              if (config.exceptions && config.exceptions.some(exc => matchedValue.includes(exc))) {
                continue;
              }

              findings.push({
                file: filePath,
                line: lineNum + 1,
                column: match.index || 0,
                match: matchedValue.slice(0, 50),
                category: category as HardcodedFinding['category'],
                severity: config.severity,
                message: config.message,
              });
            }
          }
        }
      }
    } catch (error) {
      // Skip files that can't be read
    }

    return findings;
  }

  /**
   * Scan entire project
   */
  public scanProject(): ScanResults {
    const allFindings: HardcodedFinding[] = [];
    let filesScanned = 0;

    const skipDirs = ['node_modules', '.git', 'dist', 'build', 'coverage', 'tests', 'test'];
    const pattern = path.join(this.rootDir, '**', '*.ts').replace(/\\/g, '/');
    const files = glob.sync(pattern, { ignore: skipDirs.map(d => `**/${d}/**`) });

    for (const file of files) {
      const findings = this.scanFile(file);
      allFindings.push(...findings);
      filesScanned++;
    }

    return {
      filesScanned,
      findings: allFindings,
      criticalCount: allFindings.filter(f => f.severity === 'CRITICAL').length,
      warningCount: allFindings.filter(f => f.severity === 'WARNING').length,
      infoCount: allFindings.filter(f => f.severity === 'INFO').length,
    };
  }
}

/**
 * Print results and return exit code
 */
export function printResults(results: ScanResults): number {
  console.log(`Scanned ${results.filesScanned} files`);
  console.log(
    `Findings: ${results.criticalCount} critical, ` +
    `${results.warningCount} warnings, ${results.infoCount} info`
  );

  if (results.findings.length > 0) {
    console.log('\nFindings:');
    const sortedFindings = [...results.findings].sort(
      (a, b) => severityOrder(a.severity) - severityOrder(b.severity)
    );
    for (const finding of sortedFindings) {
      console.log(`  [${finding.severity}] ${finding.file}:${finding.line}`);
      console.log(`         ${finding.message}: ${finding.match}`);
    }
  }

  return results.criticalCount > 0 ? 1 : 0;
}

function severityOrder(severity: string): number {
  const order = { CRITICAL: 0, WARNING: 1, INFO: 2 };
  return order[severity as keyof typeof order] || 3;
}

// Run if executed directly
if (require.main === module) {
  const detector = new HardcodedValueDetector();
  const results = detector.scanProject();
  const exitCode = printResults(results);
  process.exit(exitCode);
}

export default HardcodedValueDetector;
