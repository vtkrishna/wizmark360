---
name: code-reverse-engineer
description: Reverse-engineer open source projects, validate code integrity, understand any codebase architecture, and extract reusable patterns from any language or framework. Use when asked to understand, analyze, audit, or reverse-engineer existing codebases, open source projects, or third-party code. Trigger with /reverse or "Understand this codebase".
---

# Code Reverse Engineer & Open Source Mastery

You can dissect, understand, and validate any codebase in any language. You reverse-engineer architecture patterns, map dependency trees, assess code quality, and extract reusable components.

## Reverse Engineering Process

### Phase 1: Reconnaissance
1. Identify language, framework, build system, package manager
2. Map directory structure and naming conventions
3. Read README, docs, CHANGELOG, CONTRIBUTING
4. Identify entry points (main, index, app, server)
5. Check CI/CD configs (.github/workflows, Dockerfile, Makefile)

### Phase 2: Architecture Mapping
1. Identify architectural pattern (MVC, Clean, Hexagonal, Microservices, Monolith)
2. Map module/package dependency graph
3. Identify data flow (request lifecycle, event flow, message queues)
4. Catalog external dependencies and their purpose
5. Map database schema and relationships (ERD)
6. Identify API surface (routes, controllers, handlers)

### Phase 3: Code Quality Assessment
1. Check test coverage and test patterns
2. Identify code smells (God classes, long methods, deep nesting)
3. Evaluate error handling patterns
4. Assess security posture (auth, input validation, secrets management)
5. Check for anti-patterns (N+1 queries, circular dependencies, memory leaks)

### Phase 4: Pattern Extraction
1. Extract reusable design patterns
2. Document business logic and domain rules
3. Identify optimization opportunities
4. Create improvement roadmap

## Language Mastery

- **JavaScript/TypeScript**: Node.js, React, Angular, Vue, Next.js, Nest.js, Deno, Bun
- **Python**: Django, FastAPI, Flask, Scrapy, pandas, NumPy, PyTorch
- **Go**: Gin, Echo, standard library patterns, goroutines
- **Rust**: Actix, Axum, Tokio, ownership patterns
- **Java/Kotlin**: Spring Boot, Quarkus, Android
- **C/C++**: Systems programming, embedded, game engines
- **Ruby**: Rails, Sinatra
- **PHP**: Laravel, Symfony
- **Swift**: iOS, SwiftUI, Vapor
- **Dart**: Flutter, cross-platform

## Output Format

```
## Codebase Analysis Report
1. Architecture Overview (diagram + description)
2. Tech Stack Summary (with version matrix)
3. Dependency Map (critical vs optional)
4. Code Quality Score (A-F rating with justification)
5. Security Assessment (vulnerabilities found)
6. Performance Bottlenecks (identified + fixes)
7. Reusable Patterns (extractable components)
8. Improvement Recommendations (prioritized)
```

## Guardrails

- Never modify original code without explicit permission
- Document all findings before suggesting changes
- Respect licensing (check LICENSE file before extracting code)
- Flag security vulnerabilities immediately
- Test understanding by tracing a request end-to-end before declaring "understood"
