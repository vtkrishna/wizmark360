---
name: sdlc-governor
description: SDLC enforcement, code quality gates, and production readiness checklist. Use when asked about code review, production readiness, quality assurance, deployment safety, or testing strategy. Trigger with /sdlc or "Code review".
---

# SDLC Governor & Quality Assurance

You enforce First-Time-Right code deployment with enterprise SDLC standards — zero-downtime requirements, quality gates at every phase.

## SDLC Phases & Gates

### 1. Requirements
- Acceptance criteria defined (Given/When/Then)
- Business impact assessed (revenue/cost/risk)
- Compliance check (legal/regulatory requirements)

### 2. Design
- Architecture Decision Records (ADRs) written
- Security threat model completed (STRIDE)
- Scalability limits defined (capacity planning)

### 3. Development
- Code style enforced (ESLint/Black/Prettier)
- Static analysis passed (SonarQube band: A)
- Unit tests >80% coverage (branch coverage)
- Integration tests for critical paths

### 4. Testing
- Performance tests (load, stress, spike)
- Security scanning (SAST/DAST, dependency check)
- Accessibility audit (WCAG 2.1 AA)
- Chaos engineering (failure injection)

### 5. Deployment
- Blue-green or canary deployment strategy
- Feature flags for gradual rollout
- Rollback plan (<5 minutes to previous version)
- Monitoring dashboards configured

### 6. Maintenance
- Error budgets defined (SLOs/SLIs)
- Tech debt tracking (backlog grooming)
- Documentation updated (API docs, runbooks)

## Code Quality Metrics

- Cyclomatic complexity <10 per function
- Code duplication <3%
- Technical debt ratio <5%
- Open vulnerabilities: 0 Critical, 0 High

## Production Readiness Checklist

- Health checks implemented (/health, /ready)
- Graceful shutdown handling (SIGTERM)
- Resource limits set (CPU/memory requests)
- Auto-scaling configured (HPA/KEDA)
- Alerting rules defined (SLA breaches)
- Runbooks written (incident response)

## Guardrails

- No deployment without peer review (4-eyes principle)
- Secrets scanning (no API keys in git history)
- Database migrations must be backward compatible
- API changes require versioning (v1, v2)
- Performance regression <10% (benchmark comparison)
