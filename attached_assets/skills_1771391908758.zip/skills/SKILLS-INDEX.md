---
name: skills-index
description: Master index of all 14 Replit Agent Skills plus Skills Index
---

# Replit Agent Skills — Master Index (v1.0)

## Installation

1. Copy the `.agents/skills/` directory into your Replit project root
2. Each skill is auto-detected by Replit Agent from the `SKILL.md` files
3. Skills activate when you use their trigger commands or when the agent detects a matching task

## Complete Skill Inventory (14 Skills)

### Planning Layer
| # | Skill | Trigger | Description |
|---|-------|---------|-------------|
| 1 | Global CTO Architect | `/cto` | System architecture, multi-cloud, scalability, cost optimization |
| 2 | CPO Strategist | `/cpo` | Product strategy, retention, monetization, platform economics |
| 3 | Product Market Architect | `/product` | Market research, product innovation, business model design, GTM |

### AI & Intelligence Layer
| # | Skill | Trigger | Description |
|---|-------|---------|-------------|
| 4 | AI Orchestration | `/ai` | RAG pipelines, multi-agent systems, LLM fine-tuning, vector DBs |
| 5 | Prompt & Context Engineering | `/prompt` | Prompt optimization, context engineering, token cost reduction |
| 6 | Reasoning & Thinking Engine | `/think` | Deep reasoning, LRM mode, first-principles, trade-off analysis |
| 7 | Research & Ideation | `/research` | Technology trends, competitive analysis, innovation engineering |

### Coding Layer
| # | Skill | Trigger | Description |
|---|-------|---------|-------------|
| 8 | Fullstack Engineer | `/dev` | Production code, SOLID, 12-factor, testing, clean architecture |
| 9 | Code Reverse Engineer | `/reverse` | Understand any codebase, open source analysis, pattern extraction |
| 10 | Elite Debugger | `/debug` | 360-degree debugging: code, DB, APIs, memory, performance |

### Infrastructure Layer
| # | Skill | Trigger | Description |
|---|-------|---------|-------------|
| 11 | Deep Tech & Database | `/db` | Database design, query optimization, sharding, data governance |
| 12 | CI/CD & DevSecOps | `/cicd` | Pipelines, security scanning, IaC, container orchestration |

### Quality Layer
| # | Skill | Trigger | Description |
|---|-------|---------|-------------|
| 13 | SDLC Governor | `/sdlc` | Quality gates, production readiness, code review standards |

### Master Orchestrator
| # | Skill | Trigger | Description |
|---|-------|---------|-------------|
| 14 | Vibe Coding Orchestrator | `/vibe` | Combines all skills for rapid end-to-end platform building |

## Workflow Examples

**New Platform Build:**
`/cto` → Architecture → `/cpo` → Product Strategy → `/vibe` → Rapid Build → `/sdlc` → Quality Gates

**AI Feature:**
`/ai` → Design LLM integration → `/prompt` → Optimize prompts → `/db` → Vector DB setup → `/dev` → Implement → `/sdlc` → Security review

**Debug Production Issue:**
`/debug` → Root cause analysis → `/think` → Reason through fix → `/dev` → Implement fix → `/sdlc` → Verify

**Research New Product:**
`/research` → Technology trends → `/product` → Market analysis → `/think` → Evaluate trade-offs → `/cto` → Architecture → `/vibe` → Build MVP

**Understand Open Source Project:**
`/reverse` → Codebase analysis → `/think` → Architecture reasoning → `/dev` → Implement improvements
