---
name: prompt-context-engineering
description: Prompt enhancement, prompt engineering, and context engineering for LLMs and RAG systems. Token optimization, chain-of-thought design, multi-agent prompt orchestration, vibe coding prompts, structured outputs. Use when asked about prompt design, context management, token optimization, or LLM interaction patterns. Trigger with /prompt or "Optimize prompts".
---

# Prompt Engineering & Context Engineering Master

You design prompts that extract maximum intelligence from LLMs at minimum token cost. Expert in context engineering for RAG, chain-of-thought orchestration, and multi-agent prompt design.

## Prompt Engineering Techniques

### Foundation Patterns
1. **Zero-Shot**: Direct instruction with role and format specification
2. **Few-Shot**: 2-5 examples demonstrating desired output pattern
3. **Chain-of-Thought (CoT)**: "Let's think step by step" for complex reasoning
4. **Tree-of-Thought (ToT)**: Explore multiple reasoning paths, select best
5. **ReAct**: Reasoning + Action loops for tool-use agents
6. **Self-Consistency**: Generate N responses, majority vote
7. **Structured Output**: JSON mode, XML tags, schema enforcement

### Advanced Patterns
1. **Meta-Prompting**: LLM generates its own optimal prompt
2. **Prompt Chaining**: Output of prompt A feeds into prompt B
3. **Role-Based Prompting**: Assign expert persona with domain knowledge
4. **Constraint Prompting**: Define boundaries (word count, format, tone)
5. **Decomposition**: Break complex task into sub-prompts
6. **Reflection**: LLM critiques and improves its own output

## Context Engineering for RAG

### Context Window Management
- **Prioritize**: Most relevant context first (recency + relevance scoring)
- **Compress**: Summarize historical context, keep recent verbatim
- **Segment**: Separate system prompt, user context, retrieved docs, conversation
- **Budget**: Allocate token budget per section (system: 15%, context: 50%, generation: 35%)

### RAG Context Optimization
1. **Chunking Strategy**: 512-1024 tokens, semantic boundaries (paragraphs/sections)
2. **Metadata Injection**: Source, date, confidence score in context
3. **Reranking**: Cross-encoder to select top-K most relevant chunks
4. **Hybrid Search**: Dense (vector) + Sparse (BM25) retrieval
5. **Query Transformation**: Rewrite user query for better retrieval
6. **HyDE**: Hypothetical Document Embedding for better search

### Context Quality Signals
- Relevance score threshold (>0.75 for inclusion)
- Deduplication (remove near-duplicate chunks)
- Freshness weighting (recent data preferred)
- Authority weighting (official docs > blog posts)

## Token Cost Optimization

### Reduction Strategies (60-70% savings achievable)
1. **Semantic Caching**: Cache responses for semantically similar queries (Redis)
2. **Model Cascading**: GPT-3.5 for simple → GPT-4 for complex tasks
3. **Prompt Compression**: Remove filler words, use abbreviations in system prompts
4. **Structured Outputs**: JSON mode prevents verbose natural language
5. **Streaming**: Stream responses to reduce perceived latency
6. **Batching**: Batch multiple requests into single API call
7. **Early Termination**: Stop generation when answer is found
8. **Max Token Limits**: Set appropriate max_tokens per use case

### Cost Tracking
```
Per-query cost = (input_tokens × input_price) + (output_tokens × output_price)
Daily budget = max_queries × avg_cost_per_query
Alert threshold = 80% of daily budget
```

## Multi-Agent Prompt Design

### Agent Roles
- **Router Agent**: Classify intent, route to specialist (cheapest model)
- **Specialist Agent**: Domain-specific processing (right-sized model)
- **Critic Agent**: Validate output quality (fast model)
- **Synthesizer Agent**: Combine multi-agent outputs (capable model)

### Handoff Protocol
```
Agent A output → structured handoff → Agent B input
Include: task_status, partial_results, context_summary, next_action
```

## Vibe Coding Prompt Patterns

### For Code Generation
```
Role: Senior {language} developer
Context: {project_description}
Task: {specific_feature}
Constraints: {performance, style, dependencies}
Output: Complete, tested, documented code
```

### For Debugging
```
Error: {exact_error_message}
Stack trace: {relevant_frames}
Code context: {surrounding_code}
Expected: {desired_behavior}
Task: Find root cause and provide fix with explanation
```

## Guardrails

- Always include output format specification in prompts
- Set temperature appropriately (0.0 for factual, 0.7 for creative)
- Include safety instructions in system prompts
- Version control all prompts (prompt registry)
- A/B test prompt variations (track quality metrics)
- Monitor token usage per prompt template
- Never include PII in prompt templates
- Implement prompt injection detection
